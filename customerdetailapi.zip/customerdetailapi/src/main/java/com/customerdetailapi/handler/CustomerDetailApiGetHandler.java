package com.customerdetailapi.handler;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class CustomerDetailApiGetHandler implements Callable {

	private static final Map<String, String> DB_COLUMN_TO_JSON_MAPPING;
	static {
		Map<String, String> mapping = new HashMap<>();
		mapping.put("ID", "id");
		mapping.put("FIRSTNAME", "firstName");
		mapping.put("LASTNAME", "lastName");
		mapping.put("STREET", "street");
		mapping.put("CITY", "city");
		mapping.put("STATE", "state");
		mapping.put("POSTCODE", "postcode");
		mapping.put("RESOURCE_STATE", "resource_state");
		
		DB_COLUMN_TO_JSON_MAPPING = Collections.unmodifiableMap(mapping);
	}
	
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();
		@SuppressWarnings("unchecked")
		List<Map<String, String>> payload = (List<Map<String, String>>) message.getPayload();
		List<Map<String, String>> customers = new ArrayList<>();
		payload.forEach((customer -> {
			Map<String, String> customerMap = new HashMap<>();
			DB_COLUMN_TO_JSON_MAPPING.forEach((k, v) -> {
				customerMap.put(v, StringUtils.trimToEmpty(customer.get(k)));
			});
			customers.add(customerMap);
		}));
		
		return customers;
	}

}
