CREATE TABLE CUSTOMER
(
ID VARCHAR(255) NOT NULL UNIQUE,
firstName VARCHAR(255),
lastName VARCHAR(255),
street VARCHAR(255),
city VARCHAR(255),
state VARCHAR(255),
postcode VARCHAR(255),
resource_state VARCHAR(255)
);

INSERT INTO CUSTOMER VALUES('1009', 'Hilary','John','185 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1008', 'Shane','Maxwell','235 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1007', 'Zoya','Khan','6 Aus Ave','Sydney','NSW','2027',GETDATE());

INSERT INTO CUSTOMER VALUES('1006', 'Michael','Hollin','180 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1005', 'Jim','Townsend','240 Pitt St','Sydney','NSW','2010',GETDATE());

INSERT INTO CUSTOMER VALUES('1004', 'Rebecca','Harry','150 Sussex St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1003', 'Rachelle','Jacob','250 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1002', 'Harry','Clarke','150 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1001', 'Peter','Jones','150 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1000', 'Peter','Parker','50 Maxwell St','Sydney','NSW','2010',GETDATE());

INSERT INTO CUSTOMER VALUES('1019', 'Elizabeth','John','185 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1018', 'Shane','Wyne','235 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1017', 'Jasmine','Patrick','6 Aus Ave','Sydney','NSW','2027',GETDATE());

INSERT INTO CUSTOMER VALUES('1016', 'Michael','	Aiden','180 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1015', 'Connor','Townsend','240 Pitt St','Sydney','NSW','2010',GETDATE());

INSERT INTO CUSTOMER VALUES('1014', 'Jim','Harry','200 Sussex St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1013', 'Rachelle','Jacob','250 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1012','Harry','Flynn','150 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1011','Peter','Jaxon','150 George St','Sydney','NSW','2005',GETDATE());

INSERT INTO CUSTOMER VALUES('1010','Daniel','Parker','250 Maxwell St','Sydney','NSW','2010',GETDATE());

INSERT INTO CUSTOMER VALUES('1023', 'Maria','Jacob','250 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1022','Harry','Thomson','150 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1021','Peter','Thomas','150 George St','Sydney','NSW','2005',GETDATE());

INSERT INTO CUSTOMER VALUES('1020','Daniel','Matthew','250 Maxwell St','Sydney','NSW','2010',GETDATE());

INSERT INTO CUSTOMER VALUES('1029', 'Stella','Mark','185 Bond St','Sydney','NSW','2009',GETDATE());

INSERT INTO CUSTOMER VALUES('1028', 'Lily','George','235 Mark St','Sydney','NSW','2001',GETDATE());

INSERT INTO CUSTOMER VALUES('1027', 'Jasmine','Martin','6 Aus Ave','Sydney','NSW','2027',GETDATE());

INSERT INTO CUSTOMER VALUES('1026', 'Michael','	Thomas','180 George St','Sydney','NSW','2000',GETDATE());

INSERT INTO CUSTOMER VALUES('1025', 'Billy','Townsend','240 Alex St','Sydney','NSW','2013',GETDATE());

INSERT INTO CUSTOMER VALUES('1024', 'Linda','Harry','200 Sussex St','Sydney','NSW','2000',GETDATE());