# api-customerdetail
Mule Exercise

## Customer Model
JSON data sample:
{
  "resource_state": "2017-09-24",
  "id": "id1",
  "firstName": "FirstName1",
  "lastName": "Lastname1",
  "street": "120 George St",
  "city": "Sydney",
  "state": "NSW",
  "postcode": "2000"
}

resource_state: Represents the current state of the resource which is a date value. This value will be useful for update works if any update required on the customer detail and help to overcome obsolete updates.

id: The unique identifier of the customer. 

address: This is kept simple to make it easy for exercise purpose. In reality, a customer can have multiple addresses. 

## REST API
HTTPS: I just used HTTP to keep the exercise simple. In the real world, security protocols and authentication can be applied.

Get /customers: This call handles the retrieval of customers detail based on pagination. 'start' and 'count' query parameters with default values are used to control the pagination.

Get /{customerId}: This call handles the retrieval of customers detail based on id to retrieve a single customer of a specific id.

Get /customersForAPostcode{customerPostcode}: This call handles the retrieval of customers detail based on a specified post code. 

Response code: 200 as success response code for get method.

Data transform: DB object to JSON mapping using simple handler class for this exercise. 

Exception Handling: Enabled exception catch strategy to send notification to a listener in order to handle the exception.

Cache Implementation: Cache strategy implemented to prevent memory exhaustion.

Response: Response for each flow is written to a file in path test/resources/output.

Properties File: mule-app.properties file used to define certain properties for this exercise.

## Unit Test
Munit test suite with mocking capabilities used for sample unit test case. Sample responses are referred to test/resources location.

## Database
H2 database used in local host. Necessary DB scripts available in main/resources.
